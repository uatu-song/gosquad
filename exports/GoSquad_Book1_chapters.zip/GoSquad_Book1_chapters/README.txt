GO SQUAD — Book 1 — individual chapter files
J. S. Vaughn

Same text as GoSquad_Book1_REVIEW.epub v1.2 (review copy, near-final), exported 2026-10-11 from commit b6fbd02.
30 chapters + epilogue, 77,589 words. Plain UTF-8 text, Chicago typography (curly quotes, closed em dashes, spaced ellipses).
Changes since v1.0: cadence pass ch3/ch5/ch8, 25 narration "just" cuts, ch21 dialogue typo, ch25 attribution, 5 quote-punctuation sites.
No internal notes or provenance in these files.

chapter_01.txt 2167w
chapter_02.txt 3259w
chapter_03.txt 2714w
chapter_04.txt 2183w
chapter_05.txt 2290w
chapter_06.txt 1847w
chapter_07.txt 1845w
chapter_08.txt 557w
chapter_09.txt 2239w
chapter_10.txt 1924w
chapter_11.txt 1969w
chapter_12.txt 2278w
chapter_13.txt 2832w
chapter_14.txt 5812w
chapter_15.txt 4276w
chapter_16.txt 2284w
chapter_17.txt 3503w
chapter_18.txt 2098w
chapter_19.txt 2585w
chapter_20.txt 3322w
chapter_21.txt 3786w
chapter_22.txt 3456w
chapter_23.txt 2587w
chapter_24.txt 2012w
chapter_25.txt 1233w
chapter_26.txt 3035w
chapter_27.txt 1212w
chapter_28.txt 1665w
chapter_29.txt 2282w
chapter_30.txt 3496w
epilogue.txt 841w

GO SQUAD — Book 1 — individual chapter files
J. S. Vaughn

Same text as GoSquad_Book1_REVIEW.epub v1.0 (review copy, near-final), exported 2026-09-22 from commit b73d917.
30 chapters + epilogue, 77,491 words. Plain UTF-8 text, Chicago typography (curly quotes, closed em dashes, spaced ellipses). Scene breaks are a line with '#'.
No internal notes or provenance in these files.

chapter_01.txt 2169w
chapter_02.txt 3265w
chapter_03.txt 2699w
chapter_04.txt 2184w
chapter_05.txt 2295w
chapter_06.txt 1850w
chapter_07.txt 1845w
chapter_08.txt 548w
chapter_09.txt 2240w
chapter_10.txt 1927w
chapter_11.txt 1970w
chapter_12.txt 2276w
chapter_13.txt 2830w
chapter_14.txt 5800w
chapter_15.txt 4266w
chapter_16.txt 2264w
chapter_17.txt 3495w
chapter_18.txt 2098w
chapter_19.txt 2581w
chapter_20.txt 3316w
chapter_21.txt 3776w
chapter_22.txt 3455w
chapter_23.txt 2579w
chapter_24.txt 2008w
chapter_25.txt 1231w
chapter_26.txt 3036w
chapter_27.txt 1212w
chapter_28.txt 1665w
chapter_29.txt 2282w
chapter_30.txt 3488w
epilogue.txt 841w

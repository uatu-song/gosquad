# BOOK 2 — Synopsis Punch List (crew, 2026-09-06; veto open on every line)

> **STATUS 2026-09-07:** walked through with the Director, one question at a
> time. **11 closed on the page · 12, 13, 15, 16, 17, 18, 20, 21, 22 RULED · 14
> derived · 19 no change · 1–10 and 23 are the Director's to apply — the
> Director is rewriting the synopsis personally; crew touches nothing in it.**
> Rulings verbatim in `canon/book_2/DECISIONS_LOG.md`.

**Scope:** the Book 2 section of `5_story_bibles/book_4/Series_synopsis.md`
(last touched 2026-07-26) — and only that. Not a Book 2 production audit.
Each item: what the synopsis says → what canon or the shipped Book 1 page says
→ the fix → who decides. "Mechanical" = crew can apply; "Director" = a ruling.

## A. Mechanical — fix in the document, nothing to decide

1. **"Officer Marcus Webb"** (Month 1). The name is banned series-wide. → "Officer Webb" or a new first name. *Mechanical.*
2. **"Prose: NOT YET WRITTEN / Prose Pending."** Stale. 2A exists as a 19-chapter first version, 63,874 words, awaiting rebuild from studs. → Correct the status line. *Mechanical.*
3. **Ruth "Trauma surgeon."** Book 1 page: ER doctor, Johns Hopkins. → "ER doctor." *Mechanical.*
4. **"24-chapter structure."** It is now two books: 2A = chapters 1–19 (Months 1–7, ends on Ruth and Ryu discovering Exile Island); 2B = the 28-move chess endgame to Qe3#. → Split the section into two synopses with a one-line handoff between them. *Mechanical; the split itself is already ruled.*
5. **"Governor Geneva Windrow assassinated"** with no Bellatrix layer. Series canon: Geneva is a Bellatrix clone avatar; readers must NOT know that in 2A. → Keep the page-level line; add an author-level note so the synopsis stops implying she was only a governor. *Mechanical (canon exists).*

## B. Collisions with locked canon — fix to canon, no new ruling needed

6. **Month 6: "Exile Island confrontation: Go Squad discovers Ahdia's global operations."** Canon (book_2 CLAUDE.md, topology): the TEAM does not learn until Book 3; NO Ahdia POV shows operations before Ruth's discovery. → Delete the team discovery from Month 6. Month 6 keeps the TRIOMF convergence and Kain's immortality only if those survive item 15.
7. **Month 7: "Ruth and Ryu discover Ahdia's operations."** Canon: they discover at the END of 2A (topology ch19, "79 hours, Friday night → Monday morning"), and that is the book's last beat, not a mid-book turn. → Move to the 2A ending; strike the "not Ch7, not Ch13, not midpoint" possibility everywhere it lingers.
8. **Month 2: Leah investigating "Kain abuse pattern."** Canon: Leah is a BARISTA, not an investigator; the red-dress recording is hers as a victim-witness, not a case. → Reword Leah's Month 2 line; keep the Month 11 release.
9. **Prime: "three other timelines attempted before this one."** Book 3 canon locks FIVE iterations (Prime = Ahdia-1, current = Ahdia-5). → "four earlier iterations." (Belongs to 2B's synopsis after the split.)
10. **"Director Bourn revealed as internal ally (Month 6)."** Not a collision, but it is 2B/Book 3 territory in the split and reads as a reveal 2A never earns. → Move with item 4.

## C. The bridge from Book 1 as shipped — Director decisions

11. **~~Kain is officially dead when Book 1 ends.~~ CLOSED — crew error, corrected 2026-09-06.** The page says the opposite: Ruth, ch30, frozen dialogue — "Kain is no worse off than before… He's already rebuilding his mansion. His campaign is just rolling right along." The broadcast calls the night "prank calls from some yahoos"; the public never connected the giant to Kain. The struck file in the epilogue is CADENS's INTERNAL file on the creature, not a public death. → Kain is publicly alive and campaigning from Book 1's last page; the synopsis's Month 2 reactor announcement stands. *No ruling needed.* (What the public DID see of the rampage, and what CADENS told them, is a 2A world-building question, not a synopsis defect.)
12. **RULED 2026-09-07 — never dormant.** Director: "Never dormant… the secret from CADENS but not the team… the first use of the powers should also be a bit of a surprise (both if they read book 1 and if they started with book 2)." Book 1 ch30 line 91 is Ahdia lying to Bourn; no Book 1 touch. 2A withholds the power until the riot freeze; the team's non-surprise tells the reader who knew. "100%" struck — 2A opens from one-third recovery + treatment, number from the item-20 model. (See `canon/book_2/DECISIONS_LOG.md`.)
13. **RULED 2026-09-07 — grief as the cover.** The team reads Ahdia's withdrawal as grief for Firas; that misreading is 2A's misdirection. His loss is on the page in team POV only. Book 7 untouched.
14. **DERIVED (crew, veto open) — the only secret from the team is the operations.** Prognosis known (B1 ch23, frozen), power known (#12). Ruth discovers the operations and the RATE at the end of 2A.
15. **RULED 2026-09-07 — the team learns; the world doesn't.** Month 6 is dramatic irony collapsing; publicly a miraculous survival. Kain's campaign clean; Eidolon nothing to reframe yet.
16. **RULED 2026-09-07 — translocation is FAERIS.** Director: "Ahdia doesn't translocate herself--it's a FAERIS function, standard since book 1." No baseline cost for movement. Knock-ons (crew): the Geneva sniper's signature is a TECH signature; Month 12's "3min lifespan cost" for the jump is struck (the freeze is the burn). Closes 2B editorial issue #3.
17. **RULED 2026-09-07 — Kain's handler recurs, unnamed.** Two or three scenes across 2A; the team never sees her; Bellatrix stays a third-person name; her identity still unruled.
18. **RULED 2026-09-07.** 2A collects the MCC (her base) and the Intermediary's call to Kain. The fifth Tank and the wingsuits: 2B-or-later, unassigned.
19. **Whitford** — the synopsis has Tess "discovering father's complicity." Consistent with the 2026-09-02 ruling (minor in B1, corrupt, B2 threat). Keep; note that Tess left him an unread photograph in a frame (B1 ch21). *No change.*

## D. Internal to the synopsis — one model, please

20. **RULED 2026-09-07 — proportional decay, as Book 1 has it.** Table BUILT (`BASELINE_TABLE.md`); it finds a fork — the number cannot fall below ~33 under fixed monthly add-back, so the second half needs path A/B/C (crew recommends C) and Month 0 (33 vs page-strict ~10) needs confirming. **Two rulings open.** Closes 2B editorial issue #6.
21. **RULED 2026-09-07 — 28.** Planning docs update; 2B editorial issue #1 closed.
22. **RULED 2026-09-07 — undated, months allowed.** Never a year, a pinning real-world event, a named opponent or real party. §8 extended to the series.
23. **Character-arc lines that are Book 2+ voices the Book 1 page does not show** — Victor "both/and teaching," Leah "white moderate, silent complicity," Ryu "professional doctor → enabler." Not wrong; but the Book 1 character topologies record that the page's Victor is terse and Leah is blunt. → Mark these as ARCS (where they go), not baselines (where they start). *Mechanical once the character files are the baseline.*

## E. Order of work

Mechanical items (1–5, 23) can be applied in one pass now. Items 6–10 are
rewrites to existing canon and can follow the same day. Items 12–22 are the
actual Book 2 pre-production agenda; 12 and 16 gate everything else, because
Month 1 cannot be written until the Seed is back and translocation exists.

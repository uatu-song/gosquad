GO SQUAD — Book 2 (2A) — first-version chapters 1–19 + the crew documents from the synopsis discussion
Exported 2026-09-22 from commit b73d917.

chapters/: the FIRST-VERSION prose (2A, Months 1–7, ending on Ruth and Ryu discovering Exile Island). 65,516 words. NOT the rebuild — the topology marks it 'awaiting rebuild from studs'; treat as reference text. Structure notes stripped; chapter title lines kept; scene breaks as '#'. Chapter 15 is 15a+15b joined; chapter 18 is the original (its a/b split was unfinished).

crew_docs/: SYNOPSIS_PUNCH_LIST.md (23 items, walked 2026-09-07), DECISIONS_LOG.md (the nine rulings), SYNOPSIS_2A_2B_DRAFT.md (crew draft for the Director's rewrite), BASELINE_TABLE.md + csv (proportional decay; path A/B/C and Month 0 await rulings), BOOK2A_TOPOLOGY.yaml.

chapter_01.txt 8522w
chapter_02.txt 10763w
chapter_03.txt 3706w
chapter_04.txt 2681w
chapter_05.txt 3194w
chapter_06.txt 2528w
chapter_07.txt 1890w
chapter_08.txt 1386w
chapter_09.txt 2709w
chapter_10.txt 1919w
chapter_11.txt 2188w
chapter_12.txt 2446w
chapter_13.txt 3583w
chapter_14.txt 2584w
chapter_15.txt 5422w (15a+15b)
chapter_16.txt 2468w
chapter_17.txt 1664w
chapter_18.txt 2862w
chapter_19.txt 3001w

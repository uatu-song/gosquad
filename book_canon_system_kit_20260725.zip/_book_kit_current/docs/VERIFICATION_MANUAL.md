# VERIFICATION MANUAL — which checks work, and the order to use them

Trust the tools that grep the prose live. Distrust summaries (including your own memory and a
subagent's confident report) until a live query confirms them.

## The checks (run in this order)
| Tool | What it does | Trust |
|---|---|---|
| `tools/audit.py` | whole-canon check: YAML parses, codex self-consistent, prose obeys `RULES.yaml` (POV-scoped). Exit 1 blocks. | ✅ first command of every session |
| `tools/codex.py <CODE>` | resolve any thing → definition, governing rules, facts, promises, and every LIVE prose site | ✅ the filing system |
| `tools/codex.py --gaps` | what the system does NOT know: broken refs, fossils (in codex, not prose), banned codes appearing, wobbling facts | ✅ run before claiming "clean" |
| `tools/codex.py --enforce` | gate mode: exit 1 on a HARD defect (banned/absent code in prose, or broken cross-ref) | ✅ wired into the pre-commit wall |
| `tools/check_typography.py` | raw-byte typography drift (straight quotes, floating em-dashes, etc.) | ✅ gate |
| `tools/check_facts.py` / `check_promises.py` | JSONL validity; open/candidate-hole reports | ✅ |

## Two traps that each cost the pilot repo a session
- **Grep the MECHANIC, not the character name.** A continuity break rarely names the character.
- **Manuscripts use curly apostrophes (’).** A straight-`'` grep returns zero, and **zero reads as
  clean.** Normalize typography in any new grep. The tools already do (`norm()`).

## The cardinal rule
If you change a rule in the prose, change it in the codex — the codex is what the next instance reads,
and a fossil left there grows back into the next chapter written. `audit.py` + `codex.py --gaps` catch
this class; the pre-commit wall makes it un-committable.

# SYSTEM WORKFLOW — the standing authority

## Session Start Protocol
1. Read `docs/CLAUDE.md`, this file, and `docs/VERIFICATION_MANUAL.md` in full.
2. `python3 tools/audit.py` — confirm canon holds before touching anything.
3. `python3 tools/codex.py --gaps` — see what the system does NOT know; never call anything "clean" without it.
4. Read the newest `DECISIONS_LOG.md` entries — the don't-relitigate list.

## Active Query Protocol (MANDATORY)
**Do NOT respond from memory about characters, locations, or canon. Query the source EVERY TIME.**
- Resolve the code with `codex.py <CODE>` before you assert, build, grep, or spawn a subagent.
- If you can't cite it, don't state it with confidence. Emit a one-line query log showing what you resolved.
- This is not optional. The query system exists so that answers reflect what is TRUE NOW, not a summary
  that has rotted. A ruled item is not a verified item; a subagent's confident framing is not evidence.

## Session End Protocol (the codex step)
When prose or a rule changed:
1. Run the harvest (dialogue/facts/promises/structure → ledgers).
2. If a **rule** changed: update `canon/RULES.yaml`, bump `codex_meta.codex_version`, add a
   `CODEX_CHANGELOG.md` entry, and re-run `audit.py`.
3. If a code's declaration changed (INDEX.yaml): re-run `codex.py --gaps` and confirm no new fossil.
4. Add a `DECISIONS_LOG.md` entry for any craft/canon ruling. One-paragraph harvest report.

## Enforcement is a wall, not a note
The pre-commit hook (`hooks/pre-commit`) runs `audit.py`, `check_typography.py`, and
`codex.py --enforce` on every commit and BLOCKS on a hard defect — because a check that
depends on an operator remembering to run it is a check that gets skipped. Make protocols walls.

# <BOOK> — Manuscript Repo Protocol (standing duties, every session)

> ## ⛔ FIRST ACTION, EVERY SESSION
> Read this file, `docs/SYSTEM_WORKFLOW.md`, and `docs/VERIFICATION_MANUAL.md` in full.
> Then run `python3 _book_kit_current/tools/audit.py` and read the newest
> `DECISIONS_LOG.md` entries (the don't-relitigate list). Not skimmed — read.
>
> Having a rule in your context is not the same as following it. On the pilot repo,
> every recurring failure violated a protocol that was already written down. The
> reading was never the problem; the following was.

## What this repo is
- **The manuscript is canon.** `canon/` (INDEX.yaml, RULES.yaml, facts, promises) *indexes* it
  and is never canon by itself. If prose and the codex disagree, the prose wins — and you must
  update the codex, or the fossil regrows into the next chapter written.

## The two commands
- `python3 tools/audit.py` — the whole canon check in one command. Never write prose on a failing audit.
- `python3 tools/codex.py <CODE>` — resolve any thing by address; greps prose live → what's TRUE NOW.
  `--list`, `--find "str"`, `--gaps` (what the system does NOT know), `--enforce` (gate mode).

## Standing duties (the harvest protocol) — whenever prose is added/edited, before the session ends
1. New/changed dialogue, hard facts, setups/payoffs, datable events, and per-chapter structure → the ledgers.
2. Any fact that conflicts with an existing one → set the old to `wobbling`/`contradicted` and **tell the
   author. Never silently pick a winner.**
3. Run `codex.py --gaps`; resolve fossils and "appears that must not." Surface real repetition; motifs are exempt.
4. Craft decisions made in-session, with rationale → `DECISIONS_LOG.md` (the don't-relitigate list).
5. If you changed a rule in prose, change it in the codex. End with a one-paragraph harvest report.

## Rules of engagement (hard-won)
- **Surface, don't fix.** You are not here to be a savior of a mess — re-deriving already-solved things
  IS the sabotage. Only the author assigns `red-herring`/`unimportant`, or rules a wobble.
- **The function test:** before flagging ANY irregularity, ask what it DOES. It may be a deliberate device.
- **Query first; cite or don't claim; a subagent's confident framing is not evidence; every claim gets a receipt.**
- **Consult before you construct** — check whether a thing exists before building it.

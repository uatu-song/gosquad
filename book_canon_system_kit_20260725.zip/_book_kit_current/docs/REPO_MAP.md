# REPO_MAP — cold-reference map of this book's repo  (FILL IN during bootstrap)

> A whole-repo orientation map for an instance arriving cold: where things live and what each
> thing is. Not canon; verify against source before acting (summaries rot). The bootstrap agent
> fills the `<…>` slots once it has learned this repo's actual layout.

## The project in one paragraph
`<book title, author, status — drafting / revising / done. What phase; what's next.>`
The **manuscript is canon**; the `canon/` and `_book_kit_current/data/` layers index it.

## Top-level orientation
| Path | What it is |
|---|---|
| `<manuscript dir>` | **The book — the live source of truth (canon).** `<one file, or chapters; naming pattern>` |
| `canon/` (or `_book_kit_current/data/`) | INDEX.yaml (codex addresses), RULES.yaml (rules audit runs), facts/promises, CHAPTER_INDEX |
| `_book_kit_current/tools/` | the engine: `codex.py`, `audit.py`, `check_typography.py`, `query.py`, `--enforce` |
| `_book_kit_current/hooks/pre-commit` | the wall (audit + typography + `codex --enforce`) |
| `DECISIONS_LOG.md` | the don't-relitigate list, newest-first |
| `CODEX_CHANGELOG.md` | session-end log of every rule/codex change (+ `codex_version` bump) |

## Traps that have cost a session (carry these forward; add repo-specific ones as you find them)
1. Don't answer a canon question from a YAML — resolve the code with `codex.py` (it greps prose live).
2. Grep the mechanic, not the character name.
3. Curly apostrophes: a straight-`'` grep returns zero, and zero reads as clean.
4. The function test: before flagging an irregularity, ask what it DOES — it may be a device.
5. If you change a rule in prose, change it in the codex, or the fossil regrows.

## Current state & open threads
`<fill in: what's done, what's queued, what's blocked on the author.>`

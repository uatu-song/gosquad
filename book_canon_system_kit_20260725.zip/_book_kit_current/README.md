# Book canon/verification system — portable kit (current architecture, 2026-07-25)

A refreshed, book-agnostic package of the canon-indexing + verification system proven on
the RESONANCE/`pilot` repo. **This is the current spine** (codex + audit + typography +
enforcement wall) — not the older `_BOOK_SYSTEM_KIT`, which predates all of it.

Build variant here: **lighter** — codex + audit + typography + the `--enforce` commit wall,
**no seal** (you're actively editing, so no break-glass friction). To add the seal later,
copy `seal.py` from the pilot repo's `ledger/tools/` and re-add its gate to `hooks/pre-commit`.

## What's in here
```
BOOTSTRAP_RETROACTIVE.md   ← paste into a fresh session in the new repo; it stands the system up
tools/     codex.py audit.py check_typography.py check_facts.py check_promises.py query.py
           bookconfig.py   (set your paths here)   PORTING.md   (path constants to repoint)
hooks/     pre-commit      (the wall: audit + typography + codex --enforce)
data/      RULES.yaml INDEX.yaml CANON_FACTS.jsonl PROMISES.jsonl CHAPTER_INDEX.yaml  (empty templates)
docs/      CLAUDE.md SYSTEM_WORKFLOW.md VERIFICATION_MANUAL.md REPO_MAP.md  (book-agnostic scaffold)
```

## The two commands (learn these, skip the rest)
- `python3 tools/audit.py` — the whole canon check; **first command of every session.**
- `python3 tools/codex.py <CODE>` — resolve anything by address; greps prose live, reports what's TRUE NOW.
  `--list` · `--find "str"` · `--gaps` · `--enforce` (gate mode, exit 1 on hard defect).

## How to use
1. Copy this folder into the target book's repo.
2. Paste `BOOTSTRAP_RETROACTIVE.md` into a fresh Claude Code session there.
3. It reads the docs, sets paths (`tools/bookconfig.py` + `PORTING.md`), then **retroactively**
   populates the codex from the existing manuscript — incrementally, every fact cited.
4. Install the wall: `cp hooks/pre-commit .git/hooks/` (or `git config core.hooksPath hooks`).

## The operating discipline this kit exists to enforce (from the pilot repo, 2026-07-25)
The manuscript is canon; the system indexes it and never overrides it. **Read the docs first;
query before claiming; cite or don't state it; consult before you construct; a subagent's
confident framing is not evidence; every claim gets a receipt; surface, don't fix — you are
not here to be a savior of a mess.** Enforcement only works as a wall, not a note.

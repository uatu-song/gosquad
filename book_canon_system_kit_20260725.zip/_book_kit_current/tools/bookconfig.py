"""Single source of truth for THIS book's paths. Every tool imports from here.
Set these three to your repo's layout, then the engine works unmodified.
(The copied tools still contain RESONANCE-shaped literal paths in places — see
tools/PORTING.md for the exact constants to repoint; this shim is where new code
and the bootstrap agent should read paths from.)"""
import os
from pathlib import Path

# repo root = the dir this kit was copied into (…/<repo>/_book_kit_current/tools/ -> <repo>)
PROJECT_ROOT = Path(os.environ.get("BOOK_ROOT", Path(__file__).resolve().parents[2]))

MANUSCRIPT_DIR = PROJECT_ROOT / os.environ.get("BOOK_MANUSCRIPT", "manuscript")  # your chapters live here
DATA_DIR       = PROJECT_ROOT / os.environ.get("BOOK_DATA", "canon")             # INDEX.yaml / RULES.yaml / facts
CHAPTER_GLOB   = os.environ.get("BOOK_CHAPTER_GLOB", "*.txt")                     # or *.md, CH*_*.txt, etc.

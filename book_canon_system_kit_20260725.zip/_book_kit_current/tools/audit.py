#!/usr/bin/env python3
"""
audit.py — THE canon audit. One command.

    python3 ledger/tools/audit.py            # full audit
    python3 ledger/tools/audit.py --quiet    # summary only
    python3 ledger/tools/audit.py --rule R001

WHY THIS EXISTS
    On 2026-07-13 a dead mechanic ("Standard's protective aura") was cut from
    the prose. It survived in SEVEN places across FIVE codex files, and was
    found by hand, one file at a time, over an entire session. The prose was
    audited with ad-hoc greps. A bespoke regex "deletion guard" was written and
    FAILED ITS OWN TEST.

    The author's verdict: "The codex isn't the problem, it's not making it
    central that is egregious. The point of the codex is to do these types of
    audits expediently."

    So: the rules live in RESONANCE/data/RULES.yaml, and this runs them.

WHAT IT CHECKS
    1. PARSE     — every canon file loads. (Two had NEVER parsed.)
    2. FOSSILS   — the codex is grepped for statements that CONTRADICT its own
                   rules. This is what catches "seven places, five files" in one
                   command instead of one session.
    3. PROSE     — the manuscript is checked against the rules, POV-scoped via
                   CHAPTER_INDEX.yaml, with dialogue exempted where the rule
                   only governs narration.

EXIT CODE
    0 = clean or warnings only.  1 = blocking violation.
"""
import argparse, glob, os, re, sys

try:
    import yaml
except ImportError:
    sys.exit("pyyaml required")

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "..", ".."))
RULES_F = os.path.join(REPO, "RESONANCE/data/RULES.yaml")
INDEX_F = os.path.join(REPO, "RESONANCE/data/CHAPTER_INDEX.yaml")
PROSE_G = "RESONANCE/chapters_final/RESONANCE_*.txt"
CODEX_G = ["RESONANCE/data/*.yaml", "RESONANCE/data/codex/*.yaml",
           "RESONANCE/context/*.yaml", "RESONANCE/data/*.md", "RESONANCE/context/*.md"]

C = dict(red="\033[31m", yel="\033[33m", grn="\033[32m", dim="\033[2m", bold="\033[1m", off="\033[0m")
def c(s, k): return f"{C[k]}{s}{C['off']}" if sys.stdout.isatty() else s

# ── TYPOGRAPHY ───────────────────────────────────────────────────────────────
# The manuscript uses CURLY quotes (’ “ ”). Patterns are written with straight
# ones. On 2026-07-13 this made R001 — the rule guarding the proximity fossil —
# silently unable to match "doesn’t drop". A grep that cannot fire returns zero,
# and zero reads as CLEAN. Every comparison normalises first.
def norm(s):
    return (s.replace("\u2019", "'").replace("\u2018", "'")
             .replace("\u201c", '"').replace("\u201d", '"')
             .replace("\u2014", "--").replace("\u2013", "-"))

def load_yaml(p):
    with open(p, encoding="utf-8") as f:
        return yaml.safe_load(f)

def codex_files():
    out = []
    for g in CODEX_G:
        out += glob.glob(os.path.join(REPO, g))
    # the rules file and the changelog DESCRIBE the fossils; they are not fossils
    return [f for f in sorted(set(out))
            if os.path.basename(f) not in ("RULES.yaml", "CODEX_CHANGELOG.md")]

def strip_dialogue(line):
    """Remove quoted speech — constraints on narration must not fire inside dialogue."""
    return re.sub(r'"[^"]*"', " ", norm(line))

def pov_map():
    try:
        idx = load_yaml(INDEX_F)["chapters"]
    except Exception:
        return {}
    return {k: str(v.get("pov", "")) for k, v in idx.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--rule", help="run one rule id (prefix match)")
    args = ap.parse_args()

    rules = load_yaml(RULES_F)["rules"]
    if args.rule:
        rules = {k: v for k, v in rules.items() if k.startswith(args.rule)}
        if not rules:
            sys.exit(f"no rule matching {args.rule!r}")

    blocking, warning = [], []

    # ── 1. PARSE ────────────────────────────────────────────────────────────
    bad_parse = []
    for f in glob.glob(os.path.join(REPO, "RESONANCE/data/**/*.yaml"), recursive=True) + \
             glob.glob(os.path.join(REPO, "RESONANCE/context/*.yaml")):
        try:
            load_yaml(f)
        except Exception as e:
            bad_parse.append((os.path.relpath(f, REPO), str(e).split("\n")[0]))
    n_yaml = len(glob.glob(os.path.join(REPO, "RESONANCE/data/**/*.yaml"), recursive=True)) + \
             len(glob.glob(os.path.join(REPO, "RESONANCE/context/*.yaml")))
    if not args.quiet:
        print(c("\n1. PARSE", "bold"))
        print(f"   {n_yaml - len(bad_parse)}/{n_yaml} canon files parse"
              + ("" if bad_parse else c("  ✓", "grn")))
    for f, e in bad_parse:
        blocking.append(("R009_codex_must_parse", f, 0, f"does not parse: {e}"))
        if not args.quiet: print(c(f"   ✗ {f}: {e}", "red"))

    # ── 2. FOSSILS IN THE CODEX ─────────────────────────────────────────────
    if not args.quiet: print(c("\n2. FOSSILS  (codex statements contradicting the codex's own rules)", "bold"))
    cfiles = codex_files()
    n_fossil = 0
    for rid, r in rules.items():
        pats = r.get("forbidden_in_codex") or []
        if not pats: continue
        for f in cfiles:
            try:
                lines = open(f, encoding="utf-8").read().split("\n")
            except OSError:
                continue
            for i, line in enumerate(lines, 1):
                # a line that DENIES the fossil is not a fossil
                # A line that DENIES, ANNOTATES or HISTORICISES the fossil is not a fossil.
                if re.search(r"\b(no|not|never|fossil|corrected|removed|abandoned|old entry|was a|EVERYONE drops|drags)\b", line, re.I):
                    continue
                if line.lstrip().startswith("#"):
                    continue     # a comment explaining the fix is not the bug
                for p in pats:
                    if re.search(p, norm(line), re.I):
                        n_fossil += 1
                        rel = os.path.relpath(f, REPO)
                        blocking.append((rid, rel, i, line.strip()[:88]))
                        if not args.quiet:
                            print(c(f"   ✗ {rel}:{i}", "red"))
                            print(f"       {c(rid, 'dim')}  matched {p!r}")
                            print(f"       {line.strip()[:88]}")
    if not args.quiet and not n_fossil:
        print(f"   {len(cfiles)} codex files scanned — no fossils" + c("  ✓", "grn"))

    # ── 3. PROSE ────────────────────────────────────────────────────────────
    if not args.quiet: print(c("\n3. PROSE  (manuscript vs. the rules, POV-scoped)", "bold"))
    POV = pov_map()
    pfiles = sorted(glob.glob(os.path.join(REPO, PROSE_G)))
    pfiles = [f for f in pfiles if "TRANSCRIPT" not in f]
    n_prose = 0
    for rid, r in rules.items():
        pats = r.get("forbidden_in_prose") or []
        # Typography rules MUST see the raw bytes: norm() folds curly quotes to
        # straight and em dashes to '--', which would make such a rule either
        # silently never fire or flag the entire clean manuscript. (2026-07-24)
        raw_pats = r.get("forbidden_in_prose_raw") or []
        if not pats and not raw_pats: continue
        scope = r.get("pov_scope")
        dlg_ex = r.get("dialogue_exempt", False)
        sev = r.get("severity", "warning")
        cleared = [x["text"] for x in (r.get("cleared") or [])]
        for f in pfiles:
            stem = os.path.basename(f)[:-4]
            pov = POV.get(stem, "")
            if scope and scope.lower() not in pov.lower():
                continue
            # In an INTERCUT chapter we cannot know the line sits in HER section.
            # Report, but never block on it — a false block is how a tool gets ignored.
            fsev = "warning" if scope and "intercut" in pov.lower() else sev
            m = re.search(r"CH(\d+)", stem)
            chnum = int(m.group(1)) if m else 0
            for i, raw in enumerate(open(f, encoding="utf-8").read().split("\n"), 1):
                line = strip_dialogue(raw) if dlg_ex else norm(raw)
                for spec in list(pats) + [dict(x, _raw=True) for x in raw_pats]:
                    hay = raw if spec.get("_raw") else line
                    after = spec.get("chapters_after")
                    if after and chnum <= after:
                        continue
                    mt = re.search(spec["pattern"], hay)
                    if not mt:
                        continue
                    if any(norm(x) in norm(raw) for x in spec.get("allow", [])):
                        continue
                    if any(norm(cl) in norm(raw) for cl in cleared):
                        continue     # ruled a non-defect; do not re-litigate
                    n_prose += 1
                    rel = os.path.relpath(f, REPO)
                    entry = (rid, rel, i, f"'{mt.group(0)}' — {spec.get('note','')}")
                    (blocking if fsev == "blocking" else warning).append(entry)
                    if not args.quiet:
                        col = "red" if fsev == "blocking" else "yel"
                        print(c(f"   {'✗' if fsev=='blocking' else '!'} {rel}:{i}  '{mt.group(0)}'", col))
                        print(f"       {c(rid, 'dim')}  {spec.get('note','')}")
                        print(f"       {raw.strip()[:88]}")
    if not args.quiet and not n_prose:
        print(f"   {len(pfiles)} chapters scanned — no violations" + c("  ✓", "grn"))

    # ── 4. DEVICES — the device-integrity guard (Rogers Amendment, 2026-07-14) ──
    # Every `cleared`/`allow`/`protected_sites` text in RULES.yaml is an exact quote
    # of a RULED span. If one vanishes from the manuscript, ruled material was edited
    # or normalized — the record shows such deletions arrive from GOOD edits (rogers-
    # approved, blind-reader-praised), so this check runs regardless of edit quality.
    if not args.quiet: print(c("\n4. DEVICES  (ruled spans still present in the prose)", "bold"))
    all_text = norm("\n".join(open(f, encoding="utf-8").read() for f in pfiles))
    n_dev = n_gone = 0
    for rid, r in rules.items():
        anchors = [x["text"] for x in (r.get("cleared") or [])]
        anchors += list(r.get("protected_sites") or [])
        for spec in (r.get("forbidden_in_prose") or []):
            anchors += list(spec.get("allow") or [])
        for a in anchors:
            n_dev += 1
            if norm(a) not in all_text:
                n_gone += 1
                warning.append((rid, "chapters_final", 0,
                                f"RULED SPAN VANISHED: '{a[:60]}' — edited or normalized; needs a ruling or a RULES update"))
                if not args.quiet:
                    print(c(f"   ! ruled span vanished: '{a[:66]}'", "yel"))
                    print(f"       {c(rid, 'dim')}  edit touched ruled material — ruling or RULES update required")
    if not args.quiet and not n_gone:
        print(f"   {n_dev} ruled spans anchored — all present" + c("  ✓", "grn"))

    # ── SUMMARY ─────────────────────────────────────────────────────────────
    print(c("\n" + "─" * 62, "dim"))
    if not blocking and not warning:
        print(c("AUDIT CLEAN", "grn") + "  — codex parses, no fossils, prose obeys the rules.")
        return 0
    print(f"{c(str(len(blocking)) + ' BLOCKING', 'red') if blocking else '0 blocking'}"
          f"   {c(str(len(warning)) + ' warning', 'yel') if warning else '0 warnings'}")
    for rid, f, i, msg in blocking[:20]:
        print(f"  {c('BLOCK', 'red')}  {f}:{i}  {rid}  {msg}")
    for rid, f, i, msg in warning[:10]:
        print(f"  {c('warn ', 'yel')}  {f}:{i}  {rid}  {msg}")
    if len(blocking) + len(warning) > 30:
        print(f"  … and {len(blocking) + len(warning) - 30} more")
    return 1 if blocking else 0


if __name__ == "__main__":
    sys.exit(main())

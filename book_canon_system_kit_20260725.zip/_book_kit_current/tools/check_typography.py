#!/usr/bin/env python3
"""
TYPOGRAPHY ENFORCER — the round-trip drift gate.

WHY THIS EXISTS (2026-07-24). The manuscript was 100% house-style through v1
(2026-07-20). The markdown revision rounds that followed silently rewrote the
typography on import — ~4,800 curly quotes flattened to straight, 394 closed em
dashes opened to the spaced AP form — and four consecutive imports were promoted,
audited, sealed and SHIPPED to contest judges without anyone comparing the
character inventory to the last clean state. The house rules existed the whole
time in ledger/STYLE_RULES.md. Nothing executed them.

So this gate executes them, on the RAW bytes, before anything can reseal.

Two hard-won reasons this is a separate tool and not more RULES.yaml patterns:
  1. audit.py's norm() folds “ ” -> " and — -> "--" BEFORE matching. A typography
     rule written the obvious way either silently never fires (em dash) or flags
     the entire clean manuscript (quotes). Both happened. This reads raw text.
  2. Drift arrives in BULK from an import, so a census is more useful than a
     line-by-line flag: the counts tell you instantly whether prose changed or a
     converter ran over the whole book.

Usage:
    python3 ledger/tools/check_typography.py           # gate: exit 1 on any violation
    python3 ledger/tools/check_typography.py --census  # counts only, never fails
Exit 0 = clean. Exit 1 = drift found; fix before sealing.
"""
import glob
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PROSE = ["RESONANCE/chapters_final/RESONANCE_CH*.txt",
         "RESONANCE/chapters_final/RESONANCE_EP*.txt"]
# Front/back matter is rendered text too — the collaborator letter shipped with
# 13 floating dashes because only chapters_final was checked the first time.
EXTRA = ["RESONANCE/data/FRONTBACK.yaml"]

# (label, compiled pattern, why it's wrong). Every one of these is a form that a
# markdown/plain-text round-trip produces and a typeset book must never contain.
CHECKS = [
    ("straight double quote",
     re.compile(r'"'),
     'house style is curly “ ” — plain-text/markdown import drift'),
    ("straight apostrophe in word",
     re.compile(r"(?<=[A-Za-z])'(?=[A-Za-z])"),
     "house style is curly ’ (don’t, it’s) — import drift"),
    ("floating em dash ( — )",
     re.compile(r"[ ]—[ ]"),
     "house style is closed word—word (Chicago); spaced is the AP/web machine default"),
    ("mis-faced interruption quote (—“)",
     re.compile(r"(?<=\S)—“"),
     "a dash-interrupted line CLOSES: should be —”"),
    ("stray bold (**x**)",
     re.compile(r"\*\*"),
     "house style is single-* italics; ** renders as literal * glyphs in the build"),
    ("underscore italics (_x_)",
     re.compile(r"(?<![A-Za-z0-9])_[^_\n]+_(?![A-Za-z0-9])"),
     "house style is *asterisks* — underscores create phantom breaks in the build"),
    ("ellipsis character (…)",
     re.compile(r"…"),
     "house style is spaced periods '. . .'"),
    ("collapsed ellipsis (...)",
     re.compile(r"(?<!\.)\.\.\.(?!\.)"),
     "house style is spaced periods '. . .'"),
]


def files():
    out = []
    for g in PROSE + EXTRA:
        out += sorted(glob.glob(os.path.join(ROOT, g)))
    # The CH24a flight-recorder transcript is a machine-register document with its
    # own conventions (--- pause notation); it is deliberately not house-styled.
    return [f for f in out if "TRANSCRIPT" not in f]


def main():
    census = "--census" in sys.argv
    hits = {}
    for f in files():
        if f.endswith(".yaml"):
            # In YAML a straight quote is usually SYNTAX (a string delimiter), not
            # typography. Parse it and inspect only the rendered string VALUES —
            # flagging the raw bytes would make this gate a false-positive machine,
            # and a noisy gate is an ignored gate.
            import yaml as _y
            vals = []

            def _walk(o):
                if isinstance(o, dict):
                    for v in o.values(): _walk(v)
                elif isinstance(o, list):
                    for v in o: _walk(v)
                elif isinstance(o, str): vals.append(o)
            _walk(_y.safe_load(open(f, encoding="utf-8")))
            raw = "\n".join(vals)
        else:
            raw = open(f, encoding="utf-8").read()
        for label, pat, why in CHECKS:
            n = len(pat.findall(raw))
            if n:
                hits.setdefault(label, {"why": why, "n": 0, "files": []})
                hits[label]["n"] += n
                hits[label]["files"].append((os.path.relpath(f, ROOT), n))

    print("TYPOGRAPHY ENFORCER — round-trip drift gate")
    if not hits:
        print(f"  {len(files())} files scanned — house typography intact  ✓")
        return 0
    for label, d in hits.items():
        print(f"\n  ✗ {d['n']:5}  {label}")
        print(f"          {d['why']}")
        for rel, n in d["files"][:6]:
            print(f"          {n:5}  {rel}")
        if len(d["files"]) > 6:
            print(f"          … and {len(d['files']) - 6} more files")
    if census:
        print("\n(--census: reporting only)")
        return 0
    print("\n🚫 TYPOGRAPHY DRIFT — this is the import-shortcut class that shipped to judges"
          "\n   on 2026-07-24. Fix before sealing. Nothing typographic lands unilaterally.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

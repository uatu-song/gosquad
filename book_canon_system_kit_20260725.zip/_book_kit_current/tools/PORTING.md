# PORTING — repoint the copied tools to your repo

Honest note: the tools in this folder are the **working** engine, copied verbatim from the
pilot repo. They carry pilot-shaped **literal paths inline** — they are not yet drop-in
generic. Full genericization can't be done blind (it depends on your repo's actual layout),
so the bootstrap agent does it once your structure is known. `bookconfig.py` is where those
paths should be centralized; edit the tools to import from it, or mirror the layout below.

## The exact path constants each tool assumes (verified 2026-07-25)
`codex.py`:
- `RESONANCE/data/INDEX.yaml`   → your codex registry  (`data/INDEX.yaml` here)
- `RESONANCE/data/CORE.yaml`, `CHARACTERS.yaml`, `data/codex/`, `context/` → your canon-data dir
- `RESONANCE/chapters_final/RESONANCE_*`  → **your manuscript glob** (the biggest one to repoint)
- `ledger/CANON_FACTS.jsonl`, `ledger/PROMISES.jsonl`, `ledger/DECISIONS_LOG.md` → your ledger files

`audit.py`:
- `RESONANCE/data/RULES.yaml`, `RESONANCE/data/CHAPTER_INDEX.yaml`, `RESONANCE/context/`, the manuscript glob

## Two ways to port
1. **Mirror the layout** (fastest): create `<repo>/canon/` (= RESONANCE/data), put the manuscript where
   the glob expects, and the tools mostly work. Then adjust the glob pattern to your chapter naming.
2. **Centralize** (cleaner): move each literal above into `bookconfig.py` (`DATA_DIR`, `MANUSCRIPT_DIR`,
   `CHAPTER_GLOB`, ledger paths) and replace the inline literals with imports. Do this incrementally,
   running `python3 tools/audit.py` after each tool so you catch a wrong path immediately.

## Verify the port worked
- `python3 tools/audit.py` parses (empty canon = clean baseline).
- `python3 tools/codex.py --list` shows your codes once you've populated `data/INDEX.yaml`.
- `python3 tools/codex.py --find "<a distinctive phrase from ch1>"` returns its real site — proof the
  manuscript glob points at your prose (curly-apostrophe-safe; if a known phrase returns 0, the glob is wrong).

# BOOTSTRAP — instantiate the canon/verification system on an EXISTING manuscript

> Paste everything below the line into a fresh Claude Code session in the target
> book's repo, with this kit copied in. This variant is for a manuscript that is
> **already written** — the codex must be populated *retroactively* from prose that
> already exists, which is harder and more error-prone than tagging as you write.
> Work incrementally and cite every extraction; do not bulk-generate canon.

---

You are standing up a canon-indexing + verification system on an **existing** manuscript
in this repo. A reusable engine is in `_book_kit_current/`. Your job: parametrize the
engine to this repo, then **retroactively populate** the book-specific layer from the prose.

## Read these FIRST, in full — they outrank everything else, including your own reasoning
1. `docs/CLAUDE.md` — standing protocol (session-start audit, the two tools, the traps).
2. `docs/SYSTEM_WORKFLOW.md` — Active Query Protocol (MANDATORY), Session-End codex step.
3. `docs/VERIFICATION_MANUAL.md` — which checks are trusted, which are broken.
4. `docs/REPO_MAP.md` — the cold-start orientation (fill it in as you learn this repo).

## The operating rules that this system exists to enforce — internalize before acting
- **You are NOT here to fix a mess. The manuscript is canon.** The system indexes it; it
  never overrides it. Do not "improve" prose or re-derive rulings — surface, don't fix.
- **Query first.** Resolve a code with `codex.py <CODE>` before asserting anything about
  canon. Having a rule in context is not the same as following it.
- **Cite or don't claim.** Every fact you file must name its source line. No memory-based canon.
- **A subagent's confident framing is not evidence.** Verify on disk before you believe it.
- **Consult before you construct.** Before building anything, check whether it already exists.
- **Every claim gets a receipt** — paste the command output, never assert "clean."

## Step 0 — Parametrize the engine (paths)
The tools in `tools/` reference a PROJECT ROOT. Set it to this repo:
- Confirm the manuscript location (e.g. `manuscript/` or `chapters/`), then set `PROJECT_ROOT`
  in `tools/config.py` (or export `BOOK_ROOT`) so `codex.py`, `audit.py`, `seal.py` read this repo.
- Run `python3 tools/audit.py` — it should parse (empty canon = clean). This is your baseline.

## Step 1 — Retroactive ingest (the core; do it INCREMENTALLY, never in one bulk pass)
Retroactive population is where errors enter. Do one entity/chapter at a time, verify, commit.

1. **Inventory the manuscript.** List chapter files, word counts, POV per chapter → `data/CHAPTER_INDEX.yaml`.
2. **Extract entities → the codex** (`data/INDEX.yaml`), one namespace at a time, each code
   carrying its live prose sites (the tool greps them — do not hand-copy):
   `CHR-` characters · `MEC-` mechanics/props · `THM-` themes · `WRD-` watched words ·
   `PRM-` setups/payoffs · `FCT-` facts · `CON-` constraints · `RUL-` rules.
   After each namespace: `python3 tools/codex.py --list` and spot-resolve a few. Cite sites.
3. **Extract hard facts** (numbers, dates, ages, specs) → `data/CANON_FACTS.jsonl`, each with
   `sources` = the exact `CH:line`. If two sources disagree, status `wobbling` and **flag the
   author — never pick a winner.**
4. **Extract setups/payoffs** → `data/PROMISES.jsonl` (`setup-awaiting-payoff`, status `open`;
   mark `paid` only where you can cite the payoff line). Only the author rules `red-herring`.
5. **Derive rules** the prose already obeys (register, POV, banned tics, protected devices) →
   `data/RULES.yaml`. Mark protected devices explicitly (the "function test": before flagging any
   irregularity, ask what it DOES — it may be a deliberate device, not a defect).
6. **Verify the codex against the prose**: `python3 tools/codex.py --gaps` — resolve every
   fossil (a term in the codex but not the prose) and every "appears that must not."

## Step 2 — Seal + gates (make the protocols WALLS, not notes)
Once the codex reflects the prose:
- `python3 tools/seal.py seal` — baseline the manuscript. Edits now require break-glass.
- Install the pre-commit wall: copy `hooks/pre-commit` into `.git/hooks/` (or set
  `core.hooksPath hooks`). It blocks a commit on: audit violation, typography drift, seal
  drift, and `codex.py --enforce` (a banned/absent code appearing in prose, or a broken ref).
- Confirm: `python3 tools/codex.py --enforce; echo $?` → 0. Try a deliberate violation → 1.
  Enforcement that isn't a wall is theater; make it a wall.

## Step 3 — When you have a question the author can't answer immediately
Do not guess canon. Surface it as a `wobbling` fact or an open question and keep moving.
If you need help with the *system itself* (how a tool works, why a check fails, how a device
should be encoded), the reference implementation is the RESONANCE/`pilot` repo this kit came
from — its `ledger/DECISIONS_LOG.md`, `CODEX_CHANGELOG.md`, and `codex.py` are the worked
examples. Ask the author to route a system question to the pilot-repo instance if needed.

## Step 4 — Standing duties from here (the harvest protocol)
Every session that touches prose: log new dialogue/facts/promises/structure, run
`codex.py --gaps`, update the codex whenever a rule changes in prose (or the fossil regrows),
and end with a one-paragraph harvest report. Read `DECISIONS_LOG` before reopening anything.

---
*This bootstrap encodes the failure modes learned on the pilot repo (2026-07-25): retroactive
ingest is error-prone, so it is incremental and cited; enforcement only works as a wall;
and the operator's job is to read-and-follow and surface-not-fix, never to arrive as a savior.*

# Blind-pass bundle — Chess-Narrative Engine prototype

Everything the blind generation experiment needs, and nothing from the existing draft.

Scaffold: Carlsen vs Nepomniachtchi, FIDE World Championship 2021, Dubai, round 6.
136 moves, White wins by resignation. White = the street collective. This bundle
covers the **moves 1-15 checkpoint only**; nothing in it states any event past move 15.

## What to run

`external_packages/<Name>.txt` — ten complete, self-contained prompts, one per steward.
Open one, select all, paste as the first message of a fresh chat with an external model.
Add nothing before or after it. Each file already contains the three shared documents,
that character's personality card and capability file, that character's mechanical
dossier truncated to move 15, and the task instruction. Output is **beats, not prose**.

Stewards: Ahdia, Firas, Ruth, Ryu, Ben, Tess, Leah, Victor, Bourn, Kain.
Bellatrix is excluded from this round by Director ruling and is named nowhere.

## Components, if you want to reassemble differently

- `00_BRIEF.md` — the experiment's rules (used for the in-repo run, not pasted externally)
- `01_WORLD_RULES.md`, `02_FACTIONS.md`, `03_METHOD.md` — identical across all ten packages
- `04_MAPPING.md` — piece-to-character assignments, readings deliberately stripped
- `05_GAME_RECORD.md` — all 136 moves plus capture/check density per ten-move window.
  **Not included in the external packages** — it reaches past the checkpoint horizon.
- `cards/<Name>.md` — personality: voice, values, backstory, behaviour under pressure
- `cards/<Name>_capability.md` — what they can do and what it costs, filed separately
  from personality on purpose so nothing implies how a capability was acquired
- `dossiers/<Name>.md` — the FULL 136-move mechanical dossier. The external packages
  carry a rebuilt move-15 version instead; use these only past the checkpoint.

## What is deliberately absent

No steward outlines, no manuscript, no chapter drafts, no beat matrix from the earlier
canon-aware pass, no event documents. Character material is personality only, with every
in-story incident stripped. The method document contains no proper nouns from the fiction.

Output format per package: one beat per dossier event plus one per quiet span, each beat
a **Reading** (what the piece does, and the claim it supports) and a **Meaning** (what it
amounts to for that person), close third, past tense, in the character's register.
